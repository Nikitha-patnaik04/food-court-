function App() {
    return (
    <div id="app">
      <h1>CSS is great!</h1>
      <menu>
        <li>
          <button>Yes</button>
        </li>
        <li>
          <button>No</button>
        </li>
      </menu>
    </div>
  );
}

export default App;